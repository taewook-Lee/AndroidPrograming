package com.cookandroid.introduceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    // 각 라디오 버튼과 그룹 이미지뷰
    RadioGroup radioGroupClass, radioGroupPhone;
    RadioButton classA, classB, androidPhone, iPhone;
    Button imageButton;
    // 이미지 변경에 사용
    int count = 1;
    ImageView image1, image2, image3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("자기 소개 앱");

        // 각 위젯과 연결 설정
        // 1. 반 그룹과 버튼
        radioGroupClass = (RadioGroup)findViewById(R.id.radioGroupClass);
        classA = (RadioButton)findViewById(R.id.classA);
        classB = (RadioButton)findViewById(R.id.classB);

        // 2. 핸트폰 종류 그룹과 버튼
        radioGroupPhone = (RadioGroup)findViewById(R.id.radioGroupPhone);
        androidPhone = (RadioButton)findViewById(R.id.androidPhone);
        iPhone = (RadioButton)findViewById(R.id.iPhone);

        // 3. 이미지버튼과 이미지들
        imageButton = (Button)findViewById(R.id.imageButton);
        image1 = (ImageView)findViewById(R.id.image1);
        image2 = (ImageView)findViewById(R.id.image2);
        image3 = (ImageView)findViewById(R.id.image3);

        // 3. 이미지 버튼과 이미지들 리스너
        imageButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){

                int num = count % 3;

                if(num == 0){
                    image1.setVisibility(View.VISIBLE);
                    image2.setVisibility(View.GONE);
                    image3.setVisibility(View.GONE);
                }
                else if(num == 1){
                    image1.setVisibility(View.GONE);
                    image2.setVisibility(View.VISIBLE);
                    image3.setVisibility(View.GONE);
                }
                else if(num == 2){

                    image1.setVisibility(View.GONE);
                    image2.setVisibility(View.GONE);
                    image3.setVisibility(View.VISIBLE);
                }

                count++;
            }
        });
    }
}