package com.cookandroid.b_201258053__hw3;

import android.app.TabActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TabHost;
import android.widget.ViewFlipper;

@SuppressWarnings("deprecation")
public class MainActivity extends TabActivity {

    RadioGroup radioGroupClass, radioGroupPhone;
    RadioButton classA, classB, androidPhone, iPhone;

    ViewFlipper viewFlipper;
    Button ButtonStart, ButtonStop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // <1> 이름/화면 탭
        // 탭호스트 탭위젯 프레임 레이아웃들은 id가 지정되어있는데
        // 그대로 Java 에서 사용해야 탭 호스트의 구성을 인식한다.
        TabHost tabHost = getTabHost(); // 탭호스트 변수생성성

        // 탭 스펙 생성(탭을 구성하는 요소들의 집합)
        TabHost.TabSpec tabSpecSong = tabHost.newTabSpec("Name").setIndicator("이름/학번");
        tabSpecSong.setContent(R.id.tabName); //탭스펙을 탭과 연결
        tabHost.addTab(tabSpecSong); // 탭을 탭호스트에 부착

        // <2> 설문탭
        TabHost.TabSpec tabSpecArtist = tabHost.newTabSpec("Button").setIndicator("설문");
        tabSpecArtist.setContent(R.id.tabButton);
        tabHost.addTab(tabSpecArtist);

        // 반 그룹과 버튼
        radioGroupClass = (RadioGroup)findViewById(R.id.radioGroupClass);
        classA = (RadioButton)findViewById(R.id.classA);
        classB = (RadioButton)findViewById(R.id.classB);

        // 핸트폰 종류 그룹과 버튼
        radioGroupPhone = (RadioGroup)findViewById(R.id.radioGroupPhone);
        androidPhone = (RadioButton)findViewById(R.id.androidPhone);
        iPhone = (RadioButton)findViewById(R.id.iPhone);

        // <3> 사진탭
        TabHost.TabSpec tabSpecAlbum = tabHost.newTabSpec("Image").setIndicator("사진");
        tabSpecAlbum.setContent(R.id.tabImage);
        tabHost.addTab(tabSpecAlbum);

        viewFlipper = (ViewFlipper) findViewById(R.id.viewFlipper);
        ButtonStart = (Button)findViewById(R.id.ButtonStart);
        ButtonStop = (Button)findViewById(R.id.ButtonStop);


        // 1초단위로 화면 넘기기
        viewFlipper.setFlipInterval(1000);
        //사진보기 시작 버튼
        ButtonStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewFlipper.startFlipping();
            }
        });

        //사진보기 정지버튼
        ButtonStop.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                viewFlipper.stopFlipping();
            }
        });

        tabHost.setCurrentTab(0);
    }
}